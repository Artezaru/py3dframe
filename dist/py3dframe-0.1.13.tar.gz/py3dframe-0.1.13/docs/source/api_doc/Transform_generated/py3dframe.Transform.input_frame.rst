﻿py3dframe.Transform.input\_frame
================================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.input_frame