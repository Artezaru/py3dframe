﻿py3dframe.Transform.dynamic
===========================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.dynamic