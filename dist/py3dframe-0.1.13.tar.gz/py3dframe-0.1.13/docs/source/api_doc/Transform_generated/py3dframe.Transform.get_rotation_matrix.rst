﻿py3dframe.Transform.get\_rotation\_matrix
=========================================

.. currentmodule:: py3dframe

.. automethod:: Transform.get_rotation_matrix