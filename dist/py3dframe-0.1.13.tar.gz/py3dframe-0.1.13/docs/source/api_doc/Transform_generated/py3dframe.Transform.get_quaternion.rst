﻿py3dframe.Transform.get\_quaternion
===================================

.. currentmodule:: py3dframe

.. automethod:: Transform.get_quaternion