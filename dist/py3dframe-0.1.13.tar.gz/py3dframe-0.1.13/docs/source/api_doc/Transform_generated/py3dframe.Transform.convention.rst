﻿py3dframe.Transform.convention
==============================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.convention