﻿py3dframe.Transform.rotation
============================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.rotation