﻿py3dframe.Transform.quaternion
==============================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.quaternion