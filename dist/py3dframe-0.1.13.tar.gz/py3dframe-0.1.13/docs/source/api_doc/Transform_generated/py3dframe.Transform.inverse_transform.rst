﻿py3dframe.Transform.inverse\_transform
======================================

.. currentmodule:: py3dframe

.. automethod:: Transform.inverse_transform