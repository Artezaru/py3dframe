﻿py3dframe.Transform.translation
===============================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.translation