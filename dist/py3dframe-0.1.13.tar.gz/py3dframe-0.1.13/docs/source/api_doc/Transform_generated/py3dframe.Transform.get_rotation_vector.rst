﻿py3dframe.Transform.get\_rotation\_vector
=========================================

.. currentmodule:: py3dframe

.. automethod:: Transform.get_rotation_vector