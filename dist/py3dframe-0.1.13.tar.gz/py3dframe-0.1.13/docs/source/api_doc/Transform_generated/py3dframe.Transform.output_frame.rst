﻿py3dframe.Transform.output\_frame
=================================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.output_frame