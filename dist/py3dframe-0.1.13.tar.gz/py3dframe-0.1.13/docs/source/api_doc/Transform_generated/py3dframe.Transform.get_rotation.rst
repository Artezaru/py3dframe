﻿py3dframe.Transform.get\_rotation
=================================

.. currentmodule:: py3dframe

.. automethod:: Transform.get_rotation