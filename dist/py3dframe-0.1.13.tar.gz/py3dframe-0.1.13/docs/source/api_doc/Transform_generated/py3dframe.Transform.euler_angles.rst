﻿py3dframe.Transform.euler\_angles
=================================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.euler_angles