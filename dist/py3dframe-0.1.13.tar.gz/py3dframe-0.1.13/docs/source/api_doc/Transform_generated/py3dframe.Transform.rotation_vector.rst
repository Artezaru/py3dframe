﻿py3dframe.Transform.rotation\_vector
====================================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.rotation_vector