﻿py3dframe.Transform.rotation\_matrix
====================================

.. currentmodule:: py3dframe

.. autoproperty:: Transform.rotation_matrix