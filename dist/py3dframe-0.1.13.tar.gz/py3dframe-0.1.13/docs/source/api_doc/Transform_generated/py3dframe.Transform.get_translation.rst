﻿py3dframe.Transform.get\_translation
====================================

.. currentmodule:: py3dframe

.. automethod:: Transform.get_translation