﻿py3dframe.Frame.euler\_angles
=============================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.euler_angles