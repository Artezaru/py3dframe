﻿py3dframe.Frame.\_\_eq\_\_
==========================

.. currentmodule:: py3dframe

.. automethod:: Frame.__eq__