﻿py3dframe.Frame.set\_global\_rotation\_matrix
=============================================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_global_rotation_matrix