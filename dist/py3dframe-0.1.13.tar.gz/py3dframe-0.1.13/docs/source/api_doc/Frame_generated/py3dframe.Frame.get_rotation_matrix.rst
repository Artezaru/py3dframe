﻿py3dframe.Frame.get\_rotation\_matrix
=====================================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_rotation_matrix