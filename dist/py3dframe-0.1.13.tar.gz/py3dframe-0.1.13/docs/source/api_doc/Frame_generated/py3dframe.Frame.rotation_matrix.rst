﻿py3dframe.Frame.rotation\_matrix
================================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.rotation_matrix