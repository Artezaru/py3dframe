﻿py3dframe.Frame.global\_axes
============================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_axes