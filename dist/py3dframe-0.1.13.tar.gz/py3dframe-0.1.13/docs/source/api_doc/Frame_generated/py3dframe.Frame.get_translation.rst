﻿py3dframe.Frame.get\_translation
================================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_translation