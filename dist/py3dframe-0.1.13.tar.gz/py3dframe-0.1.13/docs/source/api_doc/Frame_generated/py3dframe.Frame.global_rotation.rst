﻿py3dframe.Frame.global\_rotation
================================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_rotation