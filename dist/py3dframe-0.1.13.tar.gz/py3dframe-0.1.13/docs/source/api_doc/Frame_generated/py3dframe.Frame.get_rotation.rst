﻿py3dframe.Frame.get\_rotation
=============================

.. currentmodule:: py3dframe

.. automethod:: Frame.get_rotation