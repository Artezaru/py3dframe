﻿py3dframe.Frame.load\_from\_json
================================

.. currentmodule:: py3dframe

.. automethod:: Frame.load_from_json