﻿py3dframe.Frame.set\_quaternion
===============================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_quaternion