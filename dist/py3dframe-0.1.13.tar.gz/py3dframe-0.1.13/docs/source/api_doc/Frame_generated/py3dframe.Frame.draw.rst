﻿py3dframe.Frame.draw
====================

.. currentmodule:: py3dframe

.. automethod:: Frame.draw