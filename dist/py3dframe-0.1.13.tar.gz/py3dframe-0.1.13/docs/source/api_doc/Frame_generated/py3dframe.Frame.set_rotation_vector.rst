﻿py3dframe.Frame.set\_rotation\_vector
=====================================

.. currentmodule:: py3dframe

.. automethod:: Frame.set_rotation_vector