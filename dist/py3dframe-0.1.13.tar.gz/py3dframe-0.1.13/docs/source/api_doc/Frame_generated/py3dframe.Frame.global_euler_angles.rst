﻿py3dframe.Frame.global\_euler\_angles
=====================================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_euler_angles