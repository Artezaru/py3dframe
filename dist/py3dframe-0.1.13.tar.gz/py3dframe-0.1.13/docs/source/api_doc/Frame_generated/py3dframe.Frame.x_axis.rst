﻿py3dframe.Frame.x\_axis
=======================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.x_axis