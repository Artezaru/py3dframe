﻿py3dframe.Frame.load\_from\_dict
================================

.. currentmodule:: py3dframe

.. automethod:: Frame.load_from_dict