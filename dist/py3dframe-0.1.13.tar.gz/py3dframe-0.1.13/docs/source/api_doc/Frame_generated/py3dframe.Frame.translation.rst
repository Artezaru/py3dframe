﻿py3dframe.Frame.translation
===========================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.translation