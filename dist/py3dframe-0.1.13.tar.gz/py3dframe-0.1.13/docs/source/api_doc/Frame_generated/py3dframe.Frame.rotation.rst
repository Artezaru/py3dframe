﻿py3dframe.Frame.rotation
========================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.rotation