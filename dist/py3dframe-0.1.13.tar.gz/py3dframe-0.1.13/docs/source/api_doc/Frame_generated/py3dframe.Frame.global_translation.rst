﻿py3dframe.Frame.global\_translation
===================================

.. currentmodule:: py3dframe

.. autoproperty:: Frame.global_translation